package com.example.project2;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        final EditText x = findViewById(R.id.editTextTextPersonName);
        final EditText y = findViewById(R.id.editTextTextPersonName3);
        final EditText z = findViewById(R.id.editTextTextPersonName4);
        final EditText c = findViewById(R.id.editTextTextPersonName5);
        final Button calculate = findViewById(R.id.button);
        final Button reset = findViewById(R.id.button2);
        calculate.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View view) {


                Integer.parseInt(x.getText().toString());
                Integer.parseInt(y.getText().toString());
                Integer.parseInt(z.getText().toString());
                Integer.parseInt(c.getText().toString());


                int n1 = Integer.parseInt(x.getText().toString());
                int n2 = Integer.parseInt(y.getText().toString());
                int n3 = Integer.parseInt(z.getText().toString());
                int n4 = Integer.parseInt(c.getText().toString());
                int sum = n1 + n2 + n3 + n4;
                Toast.makeText(MainActivity.this, sum + "", Toast.LENGTH_SHORT).show();
            }


        });
         reset.setOnClickListener(new View.OnClickListener() {
             @Override
             public void onClick(View view) {

                 String Text  = x.getText().toString();
                 x.setText("");
                 String Text2 = y.getText().toString() ;
                 y.setText("");
                 String Text3 = z.getText().toString();
                 z.setText("");
                 String Text4 = c.getText().toString();
                 c.setText("");
             }
         });


            }

            }




























